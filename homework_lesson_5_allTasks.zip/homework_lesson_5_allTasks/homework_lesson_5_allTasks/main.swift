//
//  main.swift
//  homework_lesson_5_allTasks
//
//  Created by Aleksej Shapran on 13.01.23.
//

import Foundation

//MARK: Task #1
//Есть массив с некоторыми числами. Все числа равны, кроме одного. Попробуйте найти!
//findUniq([ 1, 1, 1, 2, 1, 1 ]) == 2
//findUniq([ 0, 0, 0.55, 0, 0 ]) == 0.55
//Гарантируется, что массив содержит не менее 3 чисел.
//Тесты содержат очень большие массивы, так что подумайте о производительности

func findUniq(_ arr: [Double]) -> Double {
    let arr2 = Dictionary(grouping: arr, by: {$0})
    for (key,value) in arr2 {
        if value.count == 1 {
            return key
        }
    }
    return 0
}

print(findUniq([ 1, 1, 1, 2, 1, 1 ]))
print(findUniq([ 0, 0, 0.55, 0, 0 ]))

// MARK: Task #2
// I should asked to square every digit of a number and concatenate them.
// For example, if we run 9119 through the function, 811181 will come out, because 9^2 is 81 and 1^2 is 1.
// Note: The function accepts an integer and returns an integer
// Я даю число 123  Мне нужно принять этот инт и записать его по элементу в массив. Далее высчитать корень каждого digit в массике и склеить, вернув результат в инте.

func squareDigits(_ num: Int) -> Int {
  let array = String(num).compactMap {$0.wholeNumberValue}
  let squared = array.map {$0 * $0}
  return Int(squared.map {String($0)}.joined()) ?? 0
}

print(squareDigits(9119))

// MARK: Task #3
// Or square (root) or not to square (root) - взять корень у числа если это можно сделать, если нельзя то возвести число в квадрат в массиве
// Write a method, that will get an integer array as parameter and will process every number from this array.
// return a new array with processing every number of the input-array like this:
// If the number has an integer square root, take this, otherwise square the number.
// Example
// [4,3,9,7,2,1] -> [2,9,3,49,4,1]
// The input array will always contain only positive numbers, and will never be empty or null.

func squareOrSquareRoot(_ input: [Int]) -> [Int] {
    input.map { let sqrtMe = sqrt(Double($0))
    return sqrtMe == Double(Int(sqrtMe)) ? Int(sqrtMe) : $0 * $0 }
}

print(squareOrSquareRoot([2,3,1,1,7,12]))

// MARK: Task #4
// Sum of two lowest positive numbers - получить сумму первых двух самых минимальных числа в массиве
// Create a function that returns the sum of the two lowest positive numbers given an array of minimum 4 positive integers. No floats or non-positive integers will be passed.
// For example, when an array is passed like [19, 5, 42, 2, 77], the output should be 7.
// [10, 343445353, 3453445, 3453545353453] should return 3453455.

// Решение № 1
func sumOfTwoSmallestIntegersIn(_ array: [Int]) -> Int {
    let first = array.min() // пишу первый минимум
    var arrayWithoutMin = array
    arrayWithoutMin.remove(at: (arrayWithoutMin.firstIndex(of: arrayWithoutMin.min() ?? 0) ?? 0)) // удаляю из массива первый минимум
    let second = arrayWithoutMin.min() // пишу второй минимум
    return first! + second!
}

// Решение № 2
func sumOfTwoSmallestIntegersIn_One(_ array: [Int]) -> Int {
  let arraySorted = array.sorted() // сортирую
  let sum = arraySorted[0] + arraySorted[1] // складываю два наименьших
  return sum
}

print(sumOfTwoSmallestIntegersIn([7,2,3,4,8,33,17]))
//print(sumOfTwoSmallestIntegersIn_One([7,2,3,4,8,33,17]))

// MARK: Task #5
// Balanced Number - проверить являтся ли число сбалансированным
// A balanced number is a number where the sum of digits to the left of the middle digit(s) and the sum of digits to the right of the middle digit(s) are equal.
// If the number has an odd number of digits, then there is only one middle digit. (For example, 92645 has one middle digit, 6.) Otherwise, there are two middle digits. (For example, the middle digits of 1301 are 3 and 0.)
// The middle digit(s) should not be considered when determining whether a number is balanced or not, e.g. 413023 is a balanced number because the left sum and right sum are both 5.

func balancedNumber(_ number: Int) -> String {
  let digits = String(number).compactMap{$0.wholeNumberValue }
  let first = digits.dropLast (digits.count/2 + 1).reduce(0,+)
  let second = digits.dropFirst(digits.count/2 + 1).reduce(0,+)
 return first == second ? "Balanced" : "Not Balanced"
}

print(balancedNumber(7))

// MARK: Task #6
// Strong Number  - проверить являтся ли число сильным
// Strong number is the number that the sum of the factorial of its digits is equal to number itself.
// For example, 145 is strong, since 1! + 4! + 5! = 1 + 24 + 120 = 145.

func strongNumber(_ number: Int) -> String {
    let string = "\(number)".map { stride(from: 1, to: Int("\($0)")! + 1, by: 1).map({$0}).reduce(1, *) }.reduce(0, +)
    return string == number ? "STRONG!!!!" : "Not Strong !!"
}

print(strongNumber(145))
